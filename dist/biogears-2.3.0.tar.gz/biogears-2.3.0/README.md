For all the pybind11 code, please check out libBiogears/src/pybwrappers

Please excuse the lack of documentation, this is work-in-progress

For any clarifications, please contact vybhav@hipo.ai. 

NOTE : This is not part of the official biogears repo. This is an independent project.
